function deleteStudentMusic(id){
    $.ajax({
        url: '/student-music/' + id,
        type: 'DELETE',
        success: function(result){
            window.location.reload(true);
        }
    })
};
