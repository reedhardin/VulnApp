function selectBand(id){
    $("#band-selector").val(id);
}
