var mysql = require('mysql');
var pool = mysql.createPool({
  connectionLimit : 10,
  host            : 'classmysql.engr.oregonstate.edu',
  user            : 'cs340_volzm',
  password        : '8058',
  database        : 'cs340_volzm'
});

module.exports.pool = pool;
